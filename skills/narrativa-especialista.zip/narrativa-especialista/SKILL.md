---
name: narrativa-especialista
description: >
  Constrói o Documento de Narrativa completo para especialistas, mentores e infoprodutores.
  Use este skill sempre que o usuário pedir para "preencher o documento de narrativa", "construir a narrativa do especialista", "montar o documento de posicionamento", "criar a narrativa do mentor" ou qualquer variação disso.
  Também deve ser usado quando o usuário disser "faz a narrativa", "monta a narrativa", "preenche o documento" — mesmo sem mencionar explicitamente "narrativa".
  O skill extrai as informações de três fontes possíveis: transcrição de reunião de diagnóstico, respostas de entrevista já respondidas, ou perguntas feitas diretamente ao usuário no chat.
  Produz um documento de narrativa estruturado em 16 seções, com foco total no cliente do especialista — não apenas no especialista em si.
---

# Skill: Documento de Narrativa para Especialistas

## O que esse skill faz

Transforma informações brutas de um especialista (mentor, infoprodutor, palestrante, consultor) em um Documento de Narrativa completo — o documento base que alimenta VSL, criativos, conteúdo, bio, pitch de vendas e posicionamento de marca.

O documento tem **16 seções obrigatórias**, todas com foco duplo: quem é o especialista E — principalmente — quem é o cliente dele, o que ele sente, o que já tentou e para onde vai.

---

## Fontes de informação (em ordem de prioridade)

| Prioridade | Fonte | Como usar |
|---|---|---|
| 1 | Transcrição de reunião de diagnóstico | Extrair diretamente — não pedir ao usuário o que já está na transcrição |
| 2 | Documento de respostas de entrevista | Complementar e refinar o que a transcrição deixou em aberto |
| 3 | Perguntas diretas no chat | Usar apenas para lacunas que não estão em nenhuma das fontes acima |

**Regra crítica:** Nunca pedir informação que já está disponível nos documentos carregados. Leia tudo antes de perguntar qualquer coisa.

---

## As 16 seções do Documento de Narrativa

### 1. Jornada do Mentor — Quem Eu Sou
Quem é o especialista como pessoa e profissional. Credenciais reais, experiências vividas (não apenas títulos), por que ele está nesse mercado. Deve soar humano, não institucional.

**Extração:** buscar na transcrição momentos em que o especialista fala de si — trajetória, empresas, projetos passados, por que chegou até esse nicho.

---

### 2. Inimigo em Comum — Quem Eu Combato
O inimigo não é uma pessoa — é uma crença, um método falho, uma promessa vazia que o mercado vende e que não resolve o problema do cliente. Deve ser específico e visceral.

**Extração:** buscar frases como "o mercado oferece X mas não funciona", "o problema é que todo mundo faz Y", "o cliente já tentou Z e não deu certo".

---

### 3. Método Tradicional — O que o mercado usa e por que falha
Liste todos os métodos convencionais que o cliente do especialista já tentou ou que o mercado empurra. Explique racionalmente por que cada um não resolve o problema de raiz.

**Extração:** buscar na transcrição tudo que o especialista cita como "concorrência" ou "solução anterior" do cliente.

---

### 4. Soluções que os clientes tentaram e não deram certo
Diferente da seção anterior — aqui são experiências reais e específicas que o cliente já viveu. Cases negativos. O que ele comprou, contratou, tentou — e como terminou.

**Extração:** buscar na transcrição histórias de clientes que chegaram com frustrações anteriores.

---

### 5. Dores — Situações reais do dia a dia do cliente
Cenas concretas do cotidiano do cliente antes de resolver o problema. Não abstrações — situações filmáveis. O que acontece de manhã, à noite, no trabalho, em casa.

**Extração:** buscar na transcrição quando o especialista descreve o que o cliente fala nos primeiros minutos de conversa ou como é a vida dele hoje.

---

### 6. Jornada do Avatar — Para quem eu vendo
Perfil completo do cliente ideal: dados demográficos, comportamentos, hábitos, o que quer alcançar. Deve ser específico o suficiente para que o especialista reconheça a pessoa ao ler.

**Extração:** buscar na transcrição descrições de clientes atendidos, faturamento, perfil familiar, cargo, momento de vida.

---

### 7. O que o cliente ganha atingindo o resultado
Listar os ganhos — quantitativos (números, percentuais, tempo, dinheiro) e qualitativos (liberdade, tempo, relacionamento, reputação). Separar os dois tipos.

**Extração:** buscar na transcrição quando o especialista descreve o "depois" — o que muda na vida do cliente.

---

### 8. O que acontece com quem não usa o método
O custo da inação. O que o cliente perde, deixa de ganhar, continua sofrendo se não resolver o problema. Deve ser explícito, quase doloroso de ler.

**Extração:** buscar frases como "quem não faz X continua com Y", dados de custo do problema (jurídico, operacional, tempo, turnover).

---

### 9. Narrativa Central — Para onde o cliente vai
A jornada completa: ponto A → processo → ponto B. Como o cliente entra, o que passa e onde chega. Deve ser linear e clara.

**Extração:** montar a partir da esteira de produtos + os resultados prometidos pelo especialista.

---

### 10. Narrativas do Método — Por que vai funcionar
A defesa racional do mecanismo. Por que esse método é diferente de tudo que existe. Qual a lógica que o sustenta. Deve responder a objeção "mas isso não é diferente de X?".

**Extração:** buscar na transcrição quando o especialista explica a metodologia com mais profundidade — analogias, bases científicas, diferenciais.

---

### 11. Narrativas de Sustentação — Elementos racionais de apoio
Dados de mercado, estatísticas, credenciais de terceiros (parceiros, instituições), fatos que tornam o problema urgente e a solução crível. Não precisa ser do especialista — pode ser do mercado.

**Extração:** buscar na transcrição números citados, parceiros mencionados, dados do nicho.

---

### 12. Biblioteca de Histórias — Provas e cases
Cases reais de clientes atendidos, depoimentos, histórias de transformação. Se não houver depoimento formal, mapear os casos mencionados na transcrição que podem virar histórias contadas.

**Nota:** se o público tiver resistência cultural a depoimentos (como em certos mercados B2B), registrar isso e propor alternativa narrativa (autoridade por dados, não por exposição do cliente).

**Extração:** buscar histórias específicas citadas — nomes de empresas, situações descritas, resultados mencionados.

---

### 13. Jornada do Produto — O que é entregue
Descrever cada produto da esteira com clareza: nome, formato, duração, sessões, ticket, público ideal de cada um. Organizar do produto de entrada ao produto principal.

**Extração:** mapear todos os produtos citados na transcrição — mesmo os que ainda não têm nome ou esteira definida.

---

### 14. Destino — Resultado final do cliente
Uma frase ou parágrafo que resume o ponto B em termos concretos e mensuráveis. Deve ser específico o suficiente para que o cliente leia e pense "é exatamente isso que eu quero".

**Extração:** sintetizar a partir das seções 7 e 9.

---

### 15. Mecanismo / Problema Central
O problema central que o especialista resolve + o nome do mecanismo/método que resolve. Deve ser claro, memorável e diferenciado. Se o especialista já tem um nome para o método, usar. Se não, sugerir um com base no que foi descrito.

**Extração:** buscar na transcrição o nome dado ao método, ou construir a partir da descrição do processo.

---

### 16. Modelo de Negócios + Inimigo Principal
Como o negócio funciona (funil, canais de entrada, conversão). E qual é o inimigo central que a narrativa vai combater e desconstruir ao longo de todo o conteúdo — expresso em uma frase concreta e atacável.

**Extração:** buscar na transcrição como o especialista atualmente vende, quais canais usa, e qual é a crença mais nociva do mercado que ele quer derrubar.

---

## Processo de construção

### Passo 1 — Ler tudo antes de escrever qualquer coisa
Leia a transcrição completa e o documento de respostas (se houver) antes de começar. Identifique o que está disponível e o que está em aberto.

### Passo 2 — Mapear lacunas
Após a leitura, liste internamente o que falta para cada seção. Só pergunte ao usuário o que não for possível extrair ou inferir dos documentos.

### Passo 3 — Construir com voz do especialista
Escreva usando linguagem próxima da forma como o especialista fala na transcrição. Não use linguagem genérica de marketing. O documento deve soar como ele — não como um copywriter anônimo.

### Passo 4 — Priorizar o cliente, não o especialista
O foco central do documento é o avatar — quem compra, o que sente, o que viveu, para onde vai. O especialista aparece como solução, não como protagonista.

### Passo 5 — Entregar completo no chat
Entregar o documento completo em formato markdown no chat, com todas as 16 seções preenchidas. Não fragmentar em partes — entregar tudo de uma vez.

---

## Regras de escrita

- **Sem bullet points nas seções narrativas** — escrever em prosa fluida, parágrafos curtos
- **Bullet points permitidos** apenas em listas de produtos, ganhos quantitativos ou métodos tentados
- **Tom visceral** — usar a linguagem do mercado do especialista, não linguagem de marketing genérica
- **Nada de "Eu acredito que..." ou "O objetivo é..."** — afirmações diretas, sem hedge
- **Seções incompletas são sinalizadas** — se uma seção não tiver dados suficientes, escrever o que for possível e sinalizar com `[A COMPLETAR: descreva X]`
- **Cases sem nome são válidos** — se o especialista não pode citar marca, descrever o caso de forma anônima mas detalhada

---

## Exemplos de trigger correto

- "Monta o documento de narrativa do Wendel"
- "Preenche o documento de narrativa com base na reunião"
- "Com base nessa transcrição, faz a narrativa"
- "Cria o documento de posicionamento para o meu cliente"
- "Preciso do documento de narrativa para subir no drive"
- "Faz a narrativa completa do especialista"

---

## O que esse skill NÃO faz

- Não cria VSL (usar skill específico de VSL)
- Não cria cronograma de conteúdo (usar skill de cronograma)
- Não cria copy de anúncio
- Não substitui o documento de narrativa por um resumo — sempre entrega as 16 seções completas
