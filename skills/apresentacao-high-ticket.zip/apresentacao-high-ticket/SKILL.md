---
name: "apresentacao-high-ticket"
description: "Monta a apresentação de vendas high ticket no padrão M.Scale (15 slides) para o produto de um cliente, na identidade visual dele. Use ao pedir apresentação de vendas, deck de call ou slides da oferta."
---

# Apresentação de vendas high ticket · padrão M.Scale

Monta o deck que o closer usa na call de venda. São 15 slides, e cada um responde a uma pergunta que o lead faz na cabeça, de "Isso é sobre mim?" até "O que eu faço agora?". O conteúdo vem do material do cliente (proposta, PDF, transcrição) e o visual segue a identidade da marca dele.

## 1. Antes de montar

Leia todo o material do cliente e extraia:

- Nome do especialista, marca(s), logos e cores.
- Produto: o que é, para quem, a promessa e a meta em número.
- Planos e preços. Se houver vários planos, pergunte qual entra no deck. O padrão é **um plano só**.
- Entregáveis com números (frequência, quantidade, prazo).
- História do especialista: humanização, credenciais, queda com número exato e estado atual.
- Provas: volume (alunos, faturamento, obras) ou associação (nomes de peso).
- Dados de mercado que sustentam a oferta (ex.: ticket médio do serviço do lead).

Extraia os logos do PDF do cliente (com `pdfimages`, recompondo a transparência pela máscara) e envie como assets. Nunca redesenhe um logo.

**Nunca invente** estatística, prova, queda ou depoimento. O que faltar entra como placeholder entre colchetes (`[A QUEDA: momento difícil com número exato]`, `[__] alunos formados`) e é listado na resposta final.

## 2. Os 15 slides, na ordem

| # | Slide | Pergunta do lead | O que colocar |
|---|---|---|---|
| 01 | Capa | "Isso é sobre mim?" | Tese "O problema nunca foi X. Foi Y." (até 70 caracteres) + De → Para (um adjetivo que diagnostica, outro que o lead quer ser). O "De" é o diagnóstico do deck inteiro e **não muda de nome** depois. |
| 02 | Dor e diagnóstico | "Eles entendem a minha situação?" | Título em duas partes (valida e trava). 4 dores, nesta ordem: execução, dependência, estrutura, tempo. Até 85 caracteres cada, sempre em "você". Cada dor aponta para o sistema, nunca para a técnica do lead. Se o lead culpa a coisa errada, use de 2 a 4 slides extras para desmontar a ideia. |
| 03 | Proposta | "O que você está me oferecendo?" | O que é, em uma frase. Uma negação com alvo que o lead reconhece (algo que ele já comprou e não resolveu). A meta em número no fim ("Do 0 ao 100k"). |
| 04 | Especialista | "Quem é você pra me dizer isso?" | Humanização → credencial (números e marcas) → queda com número exato → estado atual, fechando com frase curta ("Ele é quem transforma X em Y."). Nunca pule a queda. |
| 05 | Antes e depois | "Como vai ser depois?" | Título: De "[frase que o lead diz para si mesmo]" para [novo estado]. 3 pares Hoje/Depois, em que cada Depois responde ao Hoje da mesma linha. |
| 06 | Prova | "Funciona pra outros?" | **Um** tipo só. Volume: números grandes. Associação: 4 nomes em grid 2 × 2, cada um com uma linha de credencial. Nunca misture os dois. |
| 07 | Método | "Qual é o caminho?" | De 4 a 8 pilares numerados, cada título um **substantivo** (nunca verbo). O 01 é sempre Posicionamento. Uma frase de encadeamento ("Cada etapa sustenta a próxima."). |
| 08 | Entregáveis | "O que eu recebo?" | 8 itens no formato "Nome · especificação com número", com o prazo no título ("em 12 meses"). Um item é de IA; se o cliente não tiver, deixe placeholder e avise. |
| 09 | Ancoragem | "Quanto isso tudo vale?" | De 6 a 8 itens com valores **redondos** e um total que bate **exatamente** com a soma. Use preços reais do material sempre que existirem. Confira a soma rodando a conta. |
| 10 | Mecanismo | "Por que isso funciona?" | Exatamente 3 elementos que se somam em um resultado (A + B + C = Resultado). |
| 11 | Bônus da call | "Por que decidir hoje?" | Slide próprio. Algo individual que consome o tempo do especialista (diagnóstico, análise 1:1), nunca material gravado. É o que justifica a condição de hoje. |
| 12 | Valor cheio | "Quanto custa?" | Só o número, grande e sozinho. Nunca revele a condição aqui. |
| 13 | Pausa | "Quanto custa?" | O mesmo número (riscado) + "Mas essa não é a condição de hoje." |
| 14 | Condição | "O que eu faço agora?" | Parcela em 12x e à vista. Regras na seção 3. |
| 15 | Fechamento | "O que eu faço agora?" | Uma constatação, nunca uma ordem ("O negócio que você ainda não tem começa com uma decisão."). Proibido "clique agora", "garanta já" ou qualquer imperativo. |

## 3. Regras de preço (padrão)

- Desconto entre 44% e 60% sobre o valor cheio.
- À vista = valor cheio × 0,40 até × 0,56, com final trocado por 7 (R$ 11.997, não R$ 12.000).
- Parcela 12x = à vista × 1,22 ÷ 12.
- Exemplo: cheio R$ 24.000 → à vista R$ 11.997 (50%) → 12x de R$ 1.219,70.

**Quando o usuário der o preço explicitamente** (ex.: "12x de 3.833 ou 50 mil à vista"), use o preço dele e diga em uma linha quais regras do padrão ficaram de fora. Se as parcelas não fecharem com o à vista, mostre a conta e explique a diferença (ex.: uma entrada que está na proposta original), colocando a explicação no slide e nas notas. Escolha um valor cheio que deixe o desconto dentro da faixa de 44% a 60%.

## 4. Visual

Layout M.Scale com a identidade do cliente:

- Fundo escuro (preto tonalizado, nunca `#000` puro) e **uma** cor de acento da marca do cliente (no padrão M.Scale é rosa ou vermelho; troque pela cor do cliente).
- Títulos grandes e em peso alto; uma palavra-chave ou a segunda metade da frase na cor de acento.
- Eyebrow com traço antes do título de cada slide ("—— O MOMENTO").
- Cabeçalho fixo no topo: "NOME DO ESPECIALISTA · MARCA".
- Rodapé fixo: logos do cliente à esquerda; paginação "01 / 15" e barra de progresso à direita.
- Capa e fechamento com faixa de acento no topo e logo grande.
- Dores com ícone de alerta em vermelho; Depois, entregáveis e método com ícone de check na cor de acento.
- Fonte sem serifa forte (ex.: Inter), uma família só, se a marca não definir outra.
- **Slides em coluna única, sem fotos dividindo o slide.** Não reserve metade do slide para foto do especialista; o conteúdo ocupa a largura toda.

## 5. Como entregar

- Crie o deck a partir do tipo de artifact **Slides** quando ele estiver disponível. Só gere .pptx se o usuário pedir esse formato.
- Notas do apresentador em todo slide: a pergunta do lead, o que falar, o que é sugestão a validar e o que falta preencher.
- Na resposta final: uma linha sobre o deck, os valores que você sugeriu (ancoragem, valor cheio, bônus) para o usuário validar, as regras do padrão que ficaram de fora e por quê, e a lista do que falta do cliente (queda, números de prova, item de IA etc.).