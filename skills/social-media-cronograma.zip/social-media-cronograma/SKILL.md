---
name: social-media-cronograma
description: >
  Use this skill to build a complete social media content calendar (cronograma) for a client.
  Trigger whenever the user mentions: cronograma, calendário de conteúdo, social media schedule,
  roteiros de conteúdo, legendas, carrossel, reels, funil de conteúdo, or asks to turn scripts/roteiros
  into a posting schedule. The skill produces a fully written cronograma with: dates, objectives,
  content type (Reels or Carrossel), material instructions, capa, slide copy (for carrosséis),
  and complete captions (legendas) — all with the correct CTA. Use this skill even if the user
  just says "monta o cronograma" or "faz o calendário" and the project documents are already loaded.
---

# Social Media Cronograma Skill

## O que esse skill faz

Transforma roteiros de conteúdo (scripts) em um cronograma completo de social media, com:
- Datas definidas (seg a sex por padrão)
- Objetivo de cada post (CONEXÃO / AUTORIDADE / ATRAÇÃO)
- Tipo de conteúdo (REELS ou CARROSSEL)
- Instrução de material para gravação
- Sugestão de CAPA (frame de destaque ou thumbnail)
- Para carrosséis: copy completa dos 5 slides
- Legenda completa de cada post
- CTA padronizado em todos os posts

---

## Fontes de informação

Os documentos do projeto já estão carregados no contexto. Use-os diretamente:

| Documento | O que extrair |
|---|---|
| Transcrição da reunião | Nicho, público, produto, história do cliente, CTA definido |
| Documento de Narrativa | Tom de voz, método, inimigo, destino do cliente |
| Análise do Avatar | Ponto A, Ponto B, dores, desejos, objeções |
| Mineração de Dados | Mensagem clara, autoridade, prova social |
| Promessa Central e Posicionamento | Bio, linhas editoriais, o que evitar |
| Roteiros (enviados pelo usuário) | Conteúdo de cada post |

Não peça informações que já estão nos documentos.

---

## Regras de montagem do cronograma

### Período e frequência
- Início: data informada pelo usuário
- Dias: segunda a sexta (padrão), salvo instrução diferente
- Volume base: 30 Reels + 8 Carrosséis (~2 por semana) = ~38 posts
- Se ultrapassar 30 dias corridos, continua adicionando dias normalmente

### Distribuição do funil
- **Semanas 1 a 4/5** — Topo e Meio misturados (CONEXÃO + AUTORIDADE)
- **Semanas finais** — Fundo concentrado (ATRAÇÃO + conversão)
- Nunca colocar posts de fundo no início do cronograma

### Objetivos
- **CONEXÃO** — identificação emocional, história, vulnerabilidade
- **AUTORIDADE** — método, prova, mecanismo, dados, resultados
- **ATRAÇÃO** — conversão, quebra de objeção, urgência, decisão

### Alternância
- Nunca repetir o mesmo objetivo dois dias seguidos
- Carrosséis preferencialmente em quarta-feira ou terça/quinta para quebrar o ritmo da semana

---

## Estrutura de cada entrada no cronograma

```
## ◆ DD/MM/AAAA — DIA DA SEMANA

**OBJETIVO:** [CONEXÃO / AUTORIDADE / ATRAÇÃO]
**TIPO:** [REELS / CARROSSEL]
**MATERIAL:** [Instrução para gravação ou criação]
**CAPA:** [Frase de destaque para thumbnail ou frame]

[SE CARROSSEL]
**SLIDES:**
- SLIDE 1 — TÍTULO: [título muito chamativo]
- SLIDE 2: [conteúdo ou dado impactante]
- SLIDE 3: [conteúdo, história ou prova]
- SLIDE 4: [continuação ou aprofundamento]
- SLIDE 5 — CTA: [chamada para o produto/isca com o CTA exato]

**LEGENDA:**
[Legenda completa, narrativa, sem bullet points, termina com o CTA]
```

---

## Regras de escrita

### Formatação geral
- NUNCA usar hífen ( , ) em nenhum texto do cronograma, legendas, slides ou exemplos
- Usar vírgulas e pontos para separar ideias
- Essa regra se aplica a todos os campos: CAPA, LEGENDA, SLIDES e qualquer instrução de texto

### Legenda de Reels
- Complementa o vídeo, não resume
- Narrativa fluida, sem bullet points, sem headers
- Tom visceral, direto, como o cliente falaria
- Parágrafos curtos (1 a 3 linhas)
- Termina sempre com o CTA exato definido pelo usuário

### Legenda de Carrossel
- Curta e provocativa
- Cria curiosidade para o conteúdo dos slides
- Termina com o CTA + emoji 👇

### Slides do Carrossel
- **Slide 1:** título chamativo, direto, provoca curiosidade ou dor. 1 linha.
- **Slides 2, 3 e 4:** conteúdo impactante, curto. Máximo 2 linhas por slide. Sem enrolação.
- **Slide 5:** CTA claro chamando para o produto ou isca. Máximo 2 linhas + CTA.
- Cada slide deve funcionar sozinho e em sequência

### Tom de voz
- Use o tom extraído dos documentos do cliente
- Agro: linguagem do campo, analogias agrícolas, direto e com profundidade espiritual quando aplicável
- Contabilidade: direto, prova com números, autoridade técnica
- Adapte sempre ao nicho e à persona do cliente

### CTA
- Usar exatamente o CTA informado pelo usuário em TODOS os posts
- Se o usuário ainda não definiu o CTA, pergunte antes de montar o cronograma (ex.: "Comente AULA que vou te enviar")
- Nunca inventar CTA diferente do definido pelo usuário
- O CTA deve aparecer na última linha da legenda e no Slide 5 de cada carrossel

---

## Regras para os slides do carrossel — detalhamento

| Slide | Função | Extensão |
|---|---|---|
| 1 | Título que para o scroll | 1 linha curta e impactante |
| 2 | Problema, dado ou provocação | 1 a 2 linhas |
| 3 | Aprofundamento, história ou prova | 1 a 2 linhas |
| 4 | Virada, solução ou consequência | 1 a 2 linhas |
| 5 | CTA direto para o produto/isca | 1 a 2 linhas + CTA |

---

## Exemplo de saída — Reels

```
## ◆ 11/05/2026 — SEGUNDA-FEIRA

**OBJETIVO:** CONEXÃO
**TIPO:** REELS
**MATERIAL:** Gravar — Roteiro TOPO 01
**CAPA:** Você construiu uma fazenda. Mas não consegue jantar em paz com sua família.

**LEGENDA:**
Você construiu uma fazenda. Tem máquina, tem terra, tem safra, tem colaborador.

Mas não consegue jantar em paz com sua família uma semana sequer.

Você chega em casa e o celular não para. Sua esposa fala com você e você responde pela metade.

Os cinco minutos viraram a noite inteira.

Isso não é problema de lavoura. Isso é problema de Solo Humano.

Comente AULA que vou te enviar.
```

---

## Exemplo de saída — Carrossel

```
## ◆ 13/05/2026 — QUARTA-FEIRA

**OBJETIVO:** AUTORIDADE
**TIPO:** CARROSSEL
**MATERIAL:** Criar arte — 5 slides
**CAPA:** O custo que você nunca colocou na planilha

**SLIDES:**
SLIDE 1: O custo que você nunca colocou na planilha
SLIDE 2: O colaborador que saiu no meio da safra levou anos de conhecimento junto. Recrutamento, treinamento, risco trabalhista. Esse custo é alto.
SLIDE 3: O retrabalho no plantio porque a comunicação falhou. Horas de máquina e insumo desperdiçados por falta de alinhamento.
SLIDE 4: O conflito que parou o pátio por dias. Isso tem valor. E sai do seu resultado todo mês.
SLIDE 5: Esse é o custo invisível de uma fazenda com Solo Humano mal preparado. Comente AULA que vou te enviar.

**LEGENDA:**
Você faz conta pra tudo dentro da fazenda. Insumo, máquina, combustível, mão de obra.

Mas tem um custo que nunca entra na planilha. E ele sai do seu bolso todo mês, silenciosamente.

Desliza e descobre onde está esse buraco na sua operação.

Comente AULA que vou te enviar. 👇
```

---

## Checklist antes de entregar

- [ ] Todos os posts têm DATA, OBJETIVO, TIPO, MATERIAL, CAPA e LEGENDA
- [ ] Carrosséis têm os 5 slides completos
- [ ] Nenhuma legenda termina sem o CTA exato
- [ ] Funil respeitado: Topo/Meio primeiro, Fundo no final
- [ ] Objetivos alternados (sem repetir o mesmo dois dias seguidos)
- [ ] Tom de voz condizente com os documentos do cliente
- [ ] CTA idêntico em todos os posts
