---
name: pip-instagram
description: Reestrutura o perfil do Instagram de um especialista, mentor ou infoprdutor para alta conversão, seguindo o método PIP (Perfil Instagram de Alta Conversão). Use esta skill sempre que o usuário pedir para "fazer o PIP", "reestruturar o perfil", "montar o perfil do Instagram", "criar a bio", "montar os destaques", "fazer os conteúdos fixados", "otimizar o perfil" ou qualquer variação disso. Também deve ser usada quando o usuário disser "faz o perfil", "monta o Instagram", "restructura o perfil" — mesmo sem mencionar explicitamente "PIP". A skill usa as informações do especialista (narrativa, produto, público-alvo, autoridade) e entrega todos os elementos do perfil prontos para publicar: bio, destaques (story a story) e 3 conteúdos fixados completos.
---

# PIP — Perfil Instagram de Alta Conversão

## Objetivo
Transformar o perfil do Instagram em uma máquina de conversão:
**Visitante → Lead → Cliente**

Cada elemento do perfil tem uma função. Se não tem função, não entra.

---

## O que esta skill entrega

1. **Bio** (nome de pesquisa + 3 linhas)
2. **Destaque 1 — Quem é Você** (7 stories completos)
3. **Destaque 2 — Produto/Método** (7 stories completos)
4. **Destaque 3 — Resultados** (orientações + estrutura)
5. **Conteúdo Fixado 1 — Venda** (carrossel completo)
6. **Conteúdo Fixado 2 — Autoridade** (carrossel completo)
7. **Conteúdo Fixado 3 — Conexão** (carrossel completo)

---

## Informações necessárias antes de começar

Antes de escrever qualquer peça, extraia (da conversa ou pergunte ao usuário):

- **Nome do especialista**
- **O que ele faz** (nicho + método)
- **Para quem** (público-alvo específico)
- **Resultado que entrega** (transformação clara)
- **Autoridade** (formação, cases, números, instituições atendidas)
- **Nome do produto/método**
- **Como o produto funciona** (pilares, estrutura)
- **Diferencial** (o que torna único)
- **História pessoal** (virada, origem)
- **CTA principal** (o que quer que a pessoa faça: clicar no link, mandar direct, comentar)

Se alguma dessas informações estiver faltando, pergunte antes de escrever.

---

## Estrutura de cada elemento

### 1. BIO

**Campo Nome (Chave de Busca):**
```
[Nome do Especialista] | [O que faz — palavra-chave de busca]
```
Exemplo: `Deise Alves | Engenharia da Identidade`

**3 linhas da bio:**
- **Linha 1 — Promessa:** O que faz + resultado claro (sem vagueza)
- **Linha 2 — Autoridade:** Prova, número, experiência ou instituição
- **Linha 3 — CTA:** Ação clara e direta

**Regras:**
- Máximo 150 caracteres no total
- Sem frase genérica ("Bem-vindo ao meu perfil", "Te ajudo a...")
- Sem texto longo
- O resultado tem que ser específico
- O CTA tem que ter verbo de ação

**Check final:**
- [ ] Dá pra entender em 5 segundos?
- [ ] Tem promessa clara com resultado?
- [ ] Tem autoridade real?
- [ ] Tem CTA com ação?

---

### 2. DESTAQUE 1 — QUEM É VOCÊ

7 stories com função específica cada:

| Story | Função | Conteúdo |
|-------|--------|----------|
| 1 | Abertura / gancho | Frase de entrada que prende — apresenta que vem história |
| 2 | Antes | Vida antes da virada — contexto de onde veio |
| 3 | Virada | O momento de mudança — insight ou ruptura |
| 4 | Depois | Onde chegou — autoridade e conquistas |
| 5 | Prova de nível | Casos de elite, instituições, números |
| 6 | Crença / missão | O que acredita — visão de mundo |
| 7 | CTA | Direciona para o link ou próxima ação |

**Regras:**
- Cada story é uma cena — termina com gancho para o próximo
- Linguagem direta, sem rodeios
- Autoridade tem que aparecer com prova real (nome de instituição, número de clientes, tempo de atuação)
- Último story sempre com CTA

---

### 3. DESTAQUE 2 — PRODUTO / MÉTODO

7 stories com função específica cada:

| Story | Função | Conteúdo |
|-------|--------|----------|
| 1 | Apresentação do método | Nome + promessa central do produto |
| 2 | O que NÃO é | Quebra objeção de categoria (não é terapia, não é coaching...) |
| 3 | Pilares / estrutura | Os componentes do método (3 a 4 pilares) |
| 4 | Para quem é | Qualificação do lead — sintomas e perfil |
| 5 | Diferenciais | O que torna único — base científica, cases, metodologia |
| 6 | Crença do método | A filosofia por trás — o porquê funciona |
| 7 | CTA | Ação clara — link, direct, comentário |

**Regras:**
- Deixar claro o que é e o que não é
- Os pilares precisam ter nome próprio (não genérico)
- A qualificação do lead (story 4) usa linguagem de sintoma ("se você sente que...", "se você está...")
- Diferencial tem que ser real e específico

---

### 4. DESTAQUE 3 — RESULTADOS

Estrutura orientativa (o usuário vai preencher com os depoimentos reais):

| Story | Conteúdo |
|-------|----------|
| 1 | Capa do destaque — "O que dizem sobre o método" |
| 2-6 | Um depoimento por story (print ou texto formatado) |
| 7 | CTA — "Quer o mesmo resultado? Link na bio" |

**Regras:**
- Depoimentos reais, com nome ou identificação do perfil
- Priorizar depoimentos com resultado específico e mensurável
- Não usar depoimentos vagos ("mudou minha vida" sem contexto)

---

### 5. CONTEÚDO FIXADO 1 — VENDA

Carrossel de 6 slides com estrutura de copy de alta conversão:

| Slide | Função | O que escrever |
|-------|--------|----------------|
| 1 | Gancho de dor | Cenário de contradição — sucesso por fora, colapso por dentro |
| 2 | Amplificação | Nomear o problema que ninguém fala — a falência invisível |
| 3 | Consequências reais | Listar o custo real do problema (específico, não genérico) |
| 4 | Quebra de crença | A mentira que o mercado vendeu — e por que não funciona |
| 5 | Apresentação da solução | Nome do método + o que é + o que não é |
| 6 | CTA | Ação clara — comentar palavra-chave, clicar no link, mandar direct |

**Regras:**
- Slide 1 tem que parar o scroll — começa no problema, não na solução
- Slide 3 usa dados reais ou consequências específicas do nicho
- Slide 5 apresenta o método com autoridade, sem modéstia
- CTA tem que ser fácil de executar (comentar uma palavra é mais fácil que clicar)

---

### 6. CONTEÚDO FIXADO 2 — AUTORIDADE

Carrossel de 5 slides contando a história de posicionamento:

| Slide | Função | O que escrever |
|-------|--------|----------------|
| 1 | Gancho — quem você era | Ponto de partida — antes da virada |
| 2 | A virada | O momento que mudou tudo — específico e emocional |
| 3 | O que construiu | O caminho até aqui — conquistas e aprendizados |
| 4 | O que acredita | A crença central — visão de mundo do especialista |
| 5 | CTA | Convite para continuar a jornada com ele |

**Regras:**
- Primeira pessoa, tom íntimo
- Não listar conquistas como currículo — contar como história
- A crença (slide 4) tem que ser ousada e específica

---

### 7. CONTEÚDO FIXADO 3 — CONEXÃO

Carrossel de 5 slides mostrando valores e bastidores:

| Slide | Função | O que escrever |
|-------|--------|----------------|
| 1 | Gancho — bastidor ou valor | Uma cena do dia a dia ou crença pessoal forte |
| 2 | Desenvolvimento | Aprofundar o valor — por que acredita nisso |
| 3 | Aplicação prática | Como isso aparece no trabalho e na vida |
| 4 | Conexão com o público | Como isso afeta o cliente — espelho |
| 5 | CTA leve | Pergunta ou convite para interação (comentar, salvar, responder) |

**Regras:**
- Tom mais leve que os outros dois — aqui é humano, não comercial
- Pode mostrar família, rotina, bastidores — desde que conecte com o posicionamento
- CTA não precisa vender — pode pedir comentário ou salvar

---

## Regras globais de escrita

- **Linguagem do público:** escrever como o cliente pensa, não como o especialista fala
- **Resultado específico:** nunca usar "transformar sua vida" — nomear o resultado real
- **Autoridade com prova:** sempre acompanhar autoridade de prova (número, instituição, caso)
- **Identidade visual:** mencionar que o cliente deve manter máx 2 fontes e 3 cores no design
- **Coerência:** todos os elementos devem reforçar o mesmo posicionamento central

---

## Formato de entrega

Entregar tudo em sequência, nomeando claramente cada seção:

```
━━━━━━━━━━━━━━━━━━━━━━
BIO
━━━━━━━━━━━━━━━━━━━━━━
[conteúdo]

━━━━━━━━━━━━━━━━━━━━━━
DESTAQUE 1 — QUEM É VOCÊ
━━━━━━━━━━━━━━━━━━━━━━
Story 1 —
[conteúdo]
---
Story 2 —
[conteúdo]
...

━━━━━━━━━━━━━━━━━━━━━━
DESTAQUE 2 — MÉTODO/PRODUTO
━━━━━━━━━━━━━━━━━━━━━━
...

━━━━━━━━━━━━━━━━━━━━━━
CONTEÚDO FIXADO 1 — VENDA
━━━━━━━━━━━━━━━━━━━━━━
Slide 1 —
[conteúdo]
---
...
```

Cada peça entregue pronta para publicar — sem placeholders, sem instruções entre colchetes no texto final.
