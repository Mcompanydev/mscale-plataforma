---
name: promessa-biografia
description: >
  Constrói a Promessa e a Biografia de posicionamento de um especialista, mentor, consultor ou infoprodutor,
  entregando 5 variações de cada uma para diferentes tipos de público e tom (educativa, comercial, pessoal, autoridade e provocativa).
  Use esta skill sempre que o usuário pedir para "criar a promessa", "montar a promessa", "escrever a promessa de posicionamento",
  "fazer a bio", "criar a biografia", "montar a bio de autoridade", "escrever a mini bio" ou qualquer variação disso.
  Também deve ser usada quando o usuário disser "faz a promessa e a bio", "monta o posicionamento em uma frase", "transforma o form em promessa"
  — mesmo sem mencionar explicitamente "promessa" ou "biografia".
  A skill puxa as respostas do Material de Oferta High Ticket e do Material de Posicionamento (ou pergunta o que faltar),
  e sempre entrega 5 versões de cada peça, uma por perfil de leitor.
---

# Skill: Promessa e Biografia (5 variações)

## O que esse skill faz

Transforma as respostas do especialista (do Material de Oferta High Ticket e do Material de Posicionamento) em duas peças centrais de posicionamento:

1. **A Promessa** — a frase única que resume a transformação que o especialista entrega.
2. **A Biografia** — a mini bio de autoridade que sustenta essa promessa.

E entrega **5 variações de cada uma**, porque a mesma promessa comunica de formas diferentes dependendo de quem lê. Um lead analítico e cético compra por um caminho; um lead movido a ação compra por outro. A skill não escolhe por você — ela te dá as 5 e você escolhe (ou testa) a que converte melhor no canal certo.

---

## O padrão validado (a base de tudo)

Toda promessa e bio produzida por esse skill segue o padrão extraído de posicionamentos validados no mercado. **Não é opcional — é o esqueleto.**

### Fórmula da Promessa

```
Ajudo [CLIENTE IDEAL] a [VERBO DE TRANSFORMAÇÃO] [RESULTADO ESPECÍFICO E MENSURÁVEL]
em [PRAZO], [MECANISMO / MÉTODO].
```

Exemplos de referência (já validados):

> "Ajudo **líderes e gestores comerciais** a **multiplicarem** suas vendas em **até 60 dias**, **reprogramando os padrões mentais que travam a execução do seu time**."

> "Ajudo **donos de agência de viagem** a **faturarem R$1 milhão por mês** em **180 dias**, usando **o mesmo método que levou a Nevada a R$20 milhões por ano**."

### Fórmula da Biografia

```
[NOME] [PROVA VIVA / RESULTADO CONCRETO QUE ELE MESMO ALCANÇOU],
e hoje ajuda [CLIENTE IDEAL] a [TRANSFORMAÇÃO CENTRAL],
através de [MECANISMO], mesmo [OBJEÇÃO OU CRENÇA COMUM QUE ELE DERRUBA].
```

---

## As 7 regras inegociáveis do padrão

Toda variação, não importa o tom, tem que respeitar estas 7 regras. Elas são o que separa uma promessa que converte de uma frase de marketing genérica.

1. **O problema real nunca é o que o cliente acha que é.** Sempre existe uma falsa causa (o que o lead aponta) e a causa raiz (o que o especialista resolve de verdade). Ex.: o lead acha que falta técnica → a raiz é um padrão emocional. O lead acha que falta marketing → a raiz é falta de processo de vendas. Toda promessa precisa apontar pra causa raiz.

2. **A causa raiz está dentro do controle do cliente.** Nunca no mercado, na concorrência, no algoritmo, na sorte. Se um lead perguntar "isso depende de algo que eu não controlo?", a resposta tem que ser não.

3. **O verbo é estratégico, nunca genérico.** Nada de "aumentar", "melhorar", "ajudar". Use o verbo que os clientes falam espontaneamente nos depoimentos (ex.: "multiplicar") ou o verbo que o especialista consegue provar e defender.

4. **O resultado é número + prazo.** Nunca abstrato. "R$1 milhão/mês em 180 dias", "multiplicar vendas em 60 dias" — nunca "vender mais".

5. **A autoridade vem de prova vivida, não de teoria.** A bio começa com um resultado concreto que o especialista viveu na pele, dentro do próprio negócio — não com "certificado em X" ou "apaixonado por Y".

6. **A promessa é defensável, não a mais bonita.** Entre uma versão vendável mas frágil e uma versão menos chamativa mas 100% comprovável, sempre a comprovável. Vender o que não se sustenta queima o especialista.

7. **O desejo profundo ≠ o desejo declarado.** O lead diz que quer "vender mais" ou "faturar mais", mas o desejo real costuma ser liberdade, autonomia, parar de se sabotar. A promessa (principalmente nas versões pessoal e provocativa) deve tocar nisso.

---

## De onde puxar cada informação

Antes de escrever, leia o Material de Oferta High Ticket e o Material de Posicionamento que o usuário preencheu. Puxe cada peça da fórmula da pergunta correta. **Nunca pergunte o que já está respondido nos formulários.**

| Peça da fórmula | Vem de qual pergunta |
|---|---|
| Cliente ideal | Posicionamento Bloco 3 (pergunta 5) + Nicho "Cliente Ideal" |
| Verbo de transformação | Ver regra 3 + depoimentos/palavras dos clientes |
| Resultado (número + prazo) | Posicionamento Bloco 3 (pergunta 7, Ponto B) + Oferta (pergunta 3, Tempo) |
| Mecanismo | Posicionamento Bloco 4 (pergunta 9) + as 4 etapas (pergunta 10) |
| Causa raiz vs. falsa causa | Posicionamento Bloco 1 (pergunta 1) + Bloco 3 (pergunta 8, o que já tentou) |
| Prova viva (pra bio) | Posicionamento Bloco 2 (pergunta 3, por que te procuram) |
| Frase de reconhecimento (pra bio) | Posicionamento Bloco 2 (pergunta 4, os "5 minutos") |
| Crença a derrubar (pra bio) | Nicho "Crenças que seu cliente tem sobre o mercado" |
| Desejo profundo | Nicho "Dor interna (Real)" + "Desejos Internos/Transformacionais" |

**Se faltar informação essencial** (cliente ideal, resultado, prazo ou mecanismo), pergunte só o que falta antes de escrever. Se faltar informação secundária, escreva mesmo assim e sinalize com `[A CONFIRMAR: X]`.

---

## A ENTREGA: 5 variações de cada peça

Esta é a parte central da skill. Você **sempre** entrega 5 versões da promessa e 5 versões da bio. Cada uma mantém o padrão e as 7 regras — o que muda é o ângulo emocional e o tipo de leitor que ela converte melhor.

### As 5 variações (perfis)

**1. Educativa** — para o lead analítico, cético, que precisa entender *por que* funciona antes de comprar.
Tom: mostra a lógica da causa raiz em linguagem clara. É a que pode chegar a 2 frases — mas continua curta e simples, nunca um parágrafo. Boa para topo de funil, artigo, aula, YouTube, LinkedIn.

**2. Comercial (direta)** — para o lead movido a ação, que já entendeu o problema e quer o resultado.
Tom: seca, punchy, resultado na frente, sem rodeio. Curta. Boa para anúncio, headline de página de vendas, CTA, bio de Instagram.

**3. Pessoal (história)** — para o lead que compra por conexão e identificação humana.
Tom: mais quente, em primeira pessoa, toca o desejo profundo (regra 7), pode carregar um pedaço de história ou de dor real. Boa para storytelling, cápsula, e-mail, legenda pessoal.

**4. Autoridade (prova)** — para o lead que confia em número, resultado e prova social.
Tom: começa e termina em prova concreta e verificável. Dados, faturamento, cases, "eu vivo isso todo dia". Boa para pitch de vendas, apresentação, webinar, mídia.

**5. Provocativa (disruptiva)** — para o lead preso no paradigma errado, que aponta a falsa causa.
Tom: confronta a crença do mercado de cara (regra 1), quebra a objeção antes de prometer. Contrária, incômoda no bom sentido. Boa para gancho de conteúdo, abertura de VSL, reels de opinião.

---

## FORMATO DE ENTREGA (use exatamente este template)

Entregue tudo no chat, em markdown, nesta ordem:

```markdown
# Promessa e Biografia — [Nome do Especialista]

## Base do posicionamento
- **Cliente ideal:** ...
- **Falsa causa (o que o lead acha):** ...
- **Causa raiz (o que você resolve):** ...
- **Verbo estratégico:** ...
- **Resultado (número + prazo):** ...
- **Mecanismo:** ...
- **Desejo profundo do lead:** ...

---

## A PROMESSA — 5 variações

### 1. Educativa
> [promessa]
*Melhor para: artigo, aula, LinkedIn, topo de funil.*

### 2. Comercial (direta)
> [promessa]
*Melhor para: anúncio, headline, bio de Instagram, CTA.*

### 3. Pessoal (história)
> [promessa]
*Melhor para: storytelling, e-mail, legenda, cápsula.*

### 4. Autoridade (prova)
> [promessa]
*Melhor para: pitch, webinar, apresentação, mídia.*

### 5. Provocativa (disruptiva)
> [promessa]
*Melhor para: gancho de conteúdo, abertura de VSL, reels de opinião.*

---

## A BIOGRAFIA — 5 variações

### 1. Educativa
> [bio]
*Melhor para: ...*

### 2. Comercial (direta)
> [bio]
*Melhor para: ...*

### 3. Pessoal (história)
> [bio]
*Melhor para: ...*

### 4. Autoridade (prova)
> [bio]
*Melhor para: ...*

### 5. Provocativa (disruptiva)
> [bio]
*Melhor para: ...*

---

## Recomendação
[Em 2-3 linhas, diga qual variação usar como principal e por quê, com base no canal/objetivo principal do especialista. Se não souber o canal principal, pergunte.]
```

---

## Regras de escrita

- **A promessa é curta: no máximo 2 frases.** A comercial e a direta idealmente cabem em 1. Se você precisou de 3+ frases, cortou pouco — volte e enxugue.
- **Linguagem simples, que qualquer um entende de primeira leitura.** Nada de frase longa cheia de vírgula, jargão de marketing ou palavra difícil. Se um leigo precisar reler pra entender, refaça. Teste mental: dá pra falar essa promessa em voz alta, de uma vez só, sem tomar fôlego no meio? Se não dá, está grande demais.
- **A bio tem no máximo 4 frases.** Bio não é currículo, é gatilho de confiança rápido.
- **Uma ideia por frase.** Não empilhe "porque... e também... mesmo que..." numa frase só. Quebre.
- **Cada variação é claramente distinta** — se duas versões ficaram parecidas, refaça. O objetivo é dar 5 ângulos reais, não 5 sinônimos.
- **Use a linguagem do mercado do especialista**, não linguagem genérica de marketing. Puxe palavras que ele mesmo usa nos formulários.
- **Nada de hedge** ("eu acredito que...", "o objetivo é..."). Afirmação direta.
- **Toda variação respeita as 7 regras inegociáveis.** O tom muda, o padrão não — mas o tom nunca é desculpa pra ficar longo. Até a provocativa e a educativa têm que ser enxutas.

---

## Exemplo de enxugamento (comprido → curto)

❌ **Longo demais:** "A maioria dos gestores comerciais já sabe a técnica e mesmo assim não executa, e é por isso que eu ajudo líderes comerciais a multiplicarem suas vendas em até 60 dias reprogramando os padrões mentais que travam a execução, porque o gargalo nunca foi o CRM e sim o sistema invisível que roda no piloto automático."

✅ **Curto e claro:** "O seu time já sabe vender — só não executa. Eu ajudo líderes comerciais a multiplicarem as vendas em 60 dias destravando o que trava a execução por dentro."

A versão curta corta a explicação longa, usa palavras simples e cabe em duas frases faláveis de uma vez.

---

## Checklist antes de entregar

- [ ] Cada promessa tem no máximo 2 frases e dá pra falar de uma vez em voz alta?
- [ ] A linguagem é simples — um leigo entende na primeira leitura, sem reler?
- [ ] As 5 promessas seguem a fórmula (cliente + verbo + resultado + prazo + mecanismo)?
- [ ] O verbo é específico, não genérico, em todas?
- [ ] Todas têm número + prazo?
- [ ] O mecanismo aponta pra causa raiz, não pro sintoma?
- [ ] A causa raiz está sob controle do cliente?
- [ ] As 5 bios começam com prova vivida, não com teoria/adjetivo?
- [ ] Cada bio conecta com a promessa e pré-quebra uma objeção?
- [ ] As 5 variações são realmente diferentes entre si (não sinônimos)?
- [ ] Tudo é defensável e comprovável pelo especialista?

---

## Exemplos de trigger correto

- "Cria a promessa e a bio do Alexandre"
- "Monta a promessa de posicionamento com base no form"
- "Transforma essas respostas em promessa"
- "Faz a mini bio de autoridade"
- "Preciso da promessa em 5 versões pra testar"
- "Escreve a bio pro Instagram e pro pitch"
- "Monta o posicionamento em uma frase"

---

## O que esse skill NÃO faz

- Não cria VSL completa (usar skill de VSL)
- Não cria cronograma de conteúdo (usar skill de cronograma)
- Não cria a oferta high ticket inteira — usa a oferta como insumo, não a substitui
- Não entrega só 1 versão — sempre as 5, salvo se o usuário pedir explicitamente uma só
