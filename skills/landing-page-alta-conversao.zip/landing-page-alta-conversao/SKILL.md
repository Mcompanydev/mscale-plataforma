---
name: "landing-page-alta-conversao"
description: "Cria landing page de alta conversão para o produto high ticket de um cliente: promessa forte, mercado, método e FAQ, com botão para o WhatsApp. Use ao pedir LP, landing page ou página de captação."
---

# Landing page de alta conversão · high ticket

O objetivo da LP **não é explicar o produto**. É gerar interesse e subir o nível de consciência do lead até ele pensar "quero ver mais como funciona" e clicar para falar no WhatsApp. A venda acontece na call, com a apresentação de vendas.

## 1. O que NÃO entra na LP

- Preço, parcelas, desconto ou condição.
- Prazo do programa ("12 meses", "6 meses").
- Lista de entregáveis, frequência de encontros, "o que você recebe".
- A apresentação de vendas copiada para a vertical. Se a página parece o deck empilhado, está errada.

## 2. Antes de escrever

- Leia o material do cliente e, se existir, a apresentação de vendas já feita: tese da capa, dores, método, mecanismo e a história do especialista.
- **Pesquise dados reais do mercado** do nicho (participação, crescimento, escassez, ticket médio, regulação), com fonte e data. Prefira fontes oficiais; quando o número vier de empresa do setor ou de "estudos" sem identificação, use com cuidado e avise o usuário.
- Nunca invente número, depoimento ou resultado. Fontes vão citadas no rodapé da página.
- Extraia os logos do material do cliente e use a mesma identidade visual do deck.

## 3. Estrutura (nesta ordem)

1. **Menu fixo:** logos à esquerda e botão "Quero saber mais" (WhatsApp) à direita.
2. **Hero com promessa forte:** um selo com o dado de mercado mais forte; uma headline que fala do mercado e da oportunidade (ex.: "O Brasil vai trocar o tijolo pelo aço. Quem estruturar o negócio primeiro fica com o mercado da região."); um subtítulo com o valor em jogo; e o botão principal "Quero saber mais como funciona".
3. **O mercado em números:** 4 cards com número grande e uma linha de contexto. Título que cria urgência ("Os números mostram uma janela aberta. E ela não fica aberta para sempre.").
4. **Por que agora:** o que mudou no mercado e o lugar que ainda está vago ("a referência na sua região ainda não existe").
5. **O erro de quem entra:** a tese da capa do deck ("O problema nunca foi X. Foi Y.") e 4 dores em cards, apontando para o sistema, nunca para a técnica do lead.
6. **O que destrava:** o mecanismo, A + B + C = Resultado.
7. **O método:** os pilares com nome em substantivo, cada um descrito como **resultado** (o que muda para o lead), nunca como entregável. Botão "Quero ver como o método funciona".
8. **Quem está por trás:** bloco curto de autoridade do especialista, com credenciais reais e a frase de estado atual.
9. **FAQ:** de 6 a 8 perguntas em sanfona (`<details>`), cobrindo pré-requisito ("Preciso já trabalhar com X?"), formação ("Preciso ser engenheiro?"), demanda ("Existe mercado na minha cidade?"), categoria ("Isso é um curso de Y?"), a maior objeção do nicho, "Quanto custa?" (resposta: depende do ponto de partida e é apresentado na conversa, **nunca o número**) e "Qual é o próximo passo?" (chamar no WhatsApp).
10. **Chamada final:** uma constatação que coloca o lead no lugar vago ("A referência em X da sua região ainda não existe. Pode ser você.") e o botão principal.
11. **Rodapé completo:** logo com uma frase sobre o negócio; coluna de contato (WhatsApp, e-mail, endereço); coluna com logo de parceiro técnico e atalhos para o método e o FAQ; copyright com CNPJ; fontes dos dados de mercado.

## 4. Botões de WhatsApp

- Todos os botões levam para `https://wa.me/<DDI+DDD+número>?text=<mensagem codificada>`, abrindo em nova aba.
- Mensagem pronta: "Olá, [Especialista]! Vi a página sobre [tema] e quero saber mais como funciona."
- O número e a mensagem ficam em **um único ajuste** da página, para trocar todos os botões juntos.
- Botão aparece no menu, no hero, depois do método e na chamada final.

## 5. Visual

- A mesma identidade do deck do cliente: fundo escuro tonalizado, uma cor de acento da marca, fonte sem serifa forte.
- Headlines grandes e em peso alto, com a segunda metade da frase na cor de acento; eyebrow em caixa alta com espaçamento antes de cada seção.
- Seções alternando dois tons de fundo; brilho radial suave na cor de acento só no hero e na chamada final.
- Botões em pílula na cor de acento, texto escuro, alvo de toque ≥ 44px, com hover.
- Responsiva: grids viram 2 colunas no tablet e 1 no celular; o texto do botão do menu some no celular e fica só o ícone.
- Ícones em SVG de traço, nunca emoji.

## 6. Como entregar

- Crie a página a partir do tipo de artifact **Design**, como página fluida (que preenche a janela e rola), marcada como interativa. Na falta do tipo, use um HTML único publicado como artifact.
- Ajuste a altura da prancheta ao conteúdo, para o fim da página não aparecer cortado.
- Na resposta final: uma linha sobre a página, o número de WhatsApp usado e onde trocá-lo, o que ficou de fora de propósito (preço, prazo, entregáveis), os dados de mercado que merecem validação do cliente, as fontes, e o aviso de que a página está privada até ser compartilhada.